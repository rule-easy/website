"use strict";
(() => {
var exports = {};
exports.id = 912;
exports.ids = [912];
exports.modules = {

/***/ 7783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 8530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 4426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 9491:
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ 4300:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 2361:
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 3685:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 5687:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 2037:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 3477:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 2781:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 6224:
/***/ ((module) => {

module.exports = require("tty");

/***/ }),

/***/ 7310:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 9796:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 7418:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./app/api/auth/[...nextauth]/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "GET": () => (handler),
  "POST": () => (handler)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(5387);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(9267);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ./node_modules/next-auth/index.js
var next_auth = __webpack_require__(4279);
var next_auth_default = /*#__PURE__*/__webpack_require__.n(next_auth);
// EXTERNAL MODULE: ./node_modules/next-auth/providers/credentials.js
var credentials = __webpack_require__(8198);
;// CONCATENATED MODULE: ./lib/config/config.tsx
async function config_GetEnvConfig() {
    // var config: Config = { backendHost: 'http://localhost:8080' }
    var config = {
        backendHost: "http://api.patternact.com"
    };
    return config;
}

// EXTERNAL MODULE: ./node_modules/axios/dist/node/axios.cjs
var node_axios = __webpack_require__(2284);
var axios_default = /*#__PURE__*/__webpack_require__.n(node_axios);
;// CONCATENATED MODULE: ./lib/interceptors/axios.ts

// https://github.com/vahid-nejad/Refresh-Token-Next-Auth
// GetEnvConfig().then((config) => {
//     const env: Config = config
//     const BASE_URL = env.backendHost
// })
// const BASE_URL = "http://localhost:8080";
const BASE_URL = "http://api.patternact.com";
/* harmony default export */ const interceptors_axios = (axios_default().create({
    baseURL: BASE_URL,
    headers: {
        "Content-Type": "application/json"
    }
}));
const axiosAuth = axios_default().create({
    baseURL: BASE_URL,
    headers: {
        "Content-Type": "application/json"
    }
});

;// CONCATENATED MODULE: ./lib/services/auth.ts


async function SignUp(signUpReq) {
    const env = await GetEnvConfig();
    try {
        console.log("Trying signup now with info - ", signUpReq);
        const auth = (await axios.post("v1/signup", signUpReq)).data;
        return auth;
    } catch (error) {
        console.error(error);
        return null;
    }
}
async function SignIn(signinReq) {
    const env = await config_GetEnvConfig();
    console.log("Trying login with info - ", signinReq);
    const auth = (await interceptors_axios.post("v1/login", signinReq)).data;
    return auth;
}

;// CONCATENATED MODULE: ./app/api/auth/[...nextauth]/route.ts



const authOptions = {
    providers: [
        (0,credentials/* default */.Z)({
            name: "Credentials",
            credentials: {
                email: {
                    label: "email",
                    type: "text",
                    placeholder: "jsmith@gmail.com"
                },
                password: {
                    label: "Password",
                    type: "password"
                }
            },
            async authorize (credentials, req) {
                if (!credentials?.email || !credentials?.password) return null;
                console.log("Trying authentication:", credentials);
                try {
                    var signinReq = {
                        email: credentials?.email,
                        password: credentials?.password
                    };
                    const authResponse = await SignIn(signinReq);
                    console.log("Successful authentication:", authResponse);
                    return authResponse.success?.data;
                } catch (e) {
                    console.log("Unsuccessful authentication");
                    return null;
                }
            }
        })
    ],
    pages: {
        signIn: "/login"
    },
    callbacks: {
        async jwt ({ token , user  }) {
            return {
                ...token,
                ...user
            };
        },
        async session ({ session , token , user  }) {
            session.user = token;
            console.log("Caching the session:", session);
            return session;
        }
    }
};
const handler = next_auth_default()(authOptions);


;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=%2FUsers%2Fpshanbhag%2FFraudGuard%2FAPIWebsite%2Fapp&appPaths=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/auth/[...nextauth]",
    resolvedPagePath: "/Users/pshanbhag/FraudGuard/APIWebsite/app/api/auth/[...nextauth]/route.ts",
    nextConfigOutput: "standalone",
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/auth/[...nextauth]/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [683,148], () => (__webpack_exec__(7418)));
module.exports = __webpack_exports__;

})();