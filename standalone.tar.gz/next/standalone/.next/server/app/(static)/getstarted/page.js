(() => {
var exports = {};
exports.id = 181;
exports.ids = [181];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 1090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 8652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 9491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 2361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 7147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 3685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 5687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 2037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 2781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 6224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 3837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 9796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 4903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4592);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6301);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7431);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(94);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4437);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6127);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5486);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6404);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2527);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3332);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7902);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3099);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(static)',
        {
        children: [
        'getstarted',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3027)), "/Users/pshanbhag/FraudGuard/APIWebsite/app/(static)/getstarted/page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4442)), "/Users/pshanbhag/FraudGuard/APIWebsite/app/(static)/getstarted/layout.tsx"],
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3658)), "/Users/pshanbhag/FraudGuard/APIWebsite/app/layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pshanbhag/FraudGuard/APIWebsite/app/(static)/getstarted/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(static)/getstarted/page"
  

/***/ }),

/***/ 1527:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5891))

/***/ }),

/***/ 9579:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8623))

/***/ }),

/***/ 5891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ DefaultLayout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/aos/dist/aos.css
var aos = __webpack_require__(6038);
// EXTERNAL MODULE: ./node_modules/aos/dist/aos.cjs.js
var aos_cjs = __webpack_require__(5250);
var aos_cjs_default = /*#__PURE__*/__webpack_require__.n(aos_cjs);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./components/page-illustration.tsx
var page_illustration = __webpack_require__(6184);
// EXTERNAL MODULE: ./components/ui/footer.tsx
var footer = __webpack_require__(3849);
// EXTERNAL MODULE: ./node_modules/next-auth/react/index.js
var react = __webpack_require__(3370);
;// CONCATENATED MODULE: ./app/(static)/getstarted/Provider.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


function Providers({ children  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(react.SessionProvider, {
        children: children
    });
}
/* harmony default export */ const Provider = (Providers);

;// CONCATENATED MODULE: ./app/(static)/getstarted/layout.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






function DefaultLayout({ children  }) {
    (0,react_.useEffect)(()=>{
        aos_cjs_default().init({
            once: true,
            disable: "phone",
            duration: 600,
            easing: "ease-out-sine"
        });
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: "grow",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Provider, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(page_illustration/* default */.Z, {}),
                        children
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    });
}


/***/ }),

/***/ 8623:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Documentation)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next-auth/react/index.js
var react = __webpack_require__(3370);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
var compiled_react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.mjs
var clsx = __webpack_require__(5892);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(9483);
// EXTERNAL MODULE: ./node_modules/uuid/dist/esm-node/v4.js + 4 modules
var v4 = __webpack_require__(5145);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/@fortawesome/react-fontawesome/index.js
var react_fontawesome = __webpack_require__(8195);
;// CONCATENATED MODULE: ./components/button.tsx





const CustomButton = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
            onClick: props.onClick,
            type: "submit",
            className: "flex items-center justify-center border border-transparent bg-indigo-600 px-4 py-1 text-base font-medium text-indigo-100 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:bg-gray-800 disabled:cursor-not-allowed",
            disabled: props.disabled,
            children: [
                props.licon && /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome.FontAwesomeIcon, {
                    icon: props.licon,
                    className: "pr-4 text-indigo-100 disabled:cursor-not-allowed"
                }),
                !props.href && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: (0,clsx/* default */.Z)({
                        "pointer-events: none": props.disabled
                    }),
                    children: [
                        " ",
                        props.text,
                        " "
                    ]
                }),
                props.href && /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                    href: props.href,
                    className: (0,clsx/* default */.Z)({
                        "pointer-events: none": props.disabled
                    }),
                    children: [
                        " ",
                        props.text,
                        " "
                    ]
                }),
                props.ricon && /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome.FontAwesomeIcon, {
                    icon: props.ricon,
                    className: "pl-4 text-indigo-100 disabled:cursor-not-allowed"
                })
            ]
        })
    });
};
/* harmony default export */ const components_button = (CustomButton);

;// CONCATENATED MODULE: ./components/label.tsx



const CustLabel = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("label", {
            className: "label",
            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: (0,clsx/* default */.Z)({
                    "text-sm label-text": true
                }, {
                    "text-gray-100": !props.disabled
                }, {
                    "text-gray-500": props.disabled
                }),
                children: props.label
            })
        })
    });
};
/* harmony default export */ const label = (CustLabel);

;// CONCATENATED MODULE: ./components/labelledinput.tsx



const LabeledInput = (props)=>{
    const onChange = async (event)=>{
        // Call the parent callback function 
        props.onChange(event.target.value);
        event.preventDefault();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            "data-aos": "fade-up",
            "data-aos-delay": "200",
            className: "form-control",
            children: [
                props.top_label && /*#__PURE__*/ jsx_runtime_.jsx(label, {
                    label: props.top_label,
                    disabled: props.disabled
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                    className: "input-group",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "text-sm bg-custom-primary",
                            children: props.label
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            onChange: onChange,
                            value: props.value,
                            type: props.type,
                            placeholder: props.placeholder,
                            className: "input input-sm input-bordered bg-gray-900 disabled:bg-gray-600 disabled:border-gray-600",
                            disabled: props.disabled
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const labelledinput = (LabeledInput);

// EXTERNAL MODULE: ./node_modules/@fortawesome/free-solid-svg-icons/index.mjs
var free_solid_svg_icons = __webpack_require__(7877);
;// CONCATENATED MODULE: ./components/modeldisplay.tsx





const ModelDisplay = (props)=>{
    const [schema, setSchema] = compiled_react_default().useState("");
    const [schemaJSON, setSchemaJSON] = compiled_react_default().useState(JSON.parse("{}"));
    const [validJSON, setValidJSON] = compiled_react_default().useState(false);
    const onChange = async (e)=>{
        if (e.target.value == "") {
            setSchema(e.target.value);
            props.onChange(e.target.value);
            return;
        }
        setSchema(e.target.value);
        try {
            JSON.parse(e.target.value);
            setSchemaJSON(JSON.parse(e.target.value));
            setValidJSON(true);
        } catch  {
            console.log("Not a valid JSON yet");
            setSchemaJSON(e.target.value);
            setValidJSON(false);
        }
        props.onChange(e.target.value);
    };
    const beautify = async ()=>{
        console.log(schema);
        var beautifiedValue = JSON.stringify(JSON.parse(schema), null, "   ");
        setSchema(beautifiedValue);
        props.onChange(schema);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (0,clsx/* default */.Z)({
            "bg-gray-900 p-0 m-0 min-w-full min-h-full rounded-t-md outline outline-1 outline-gray-700 overflow-hidden": true
        }),
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row m-1 justify-end",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (0,clsx/* default */.Z)({
                            "font-mono font-semibold text-xs mr-3 pointer-events: none": true
                        }, {
                            "text-green-400": validJSON
                        }, {
                            "text-red-400": !validJSON
                        }),
                        children: [
                            " ",
                            "{ VALID JSON }",
                            " "
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome.FontAwesomeIcon, {
                        onClick: ()=>beautify(),
                        icon: free_solid_svg_icons/* faFan */.bty,
                        className: "cursor-pointer outline-none justify-self-end hover:text-indigo-500"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                onChange: onChange,
                className: "textarea m-0 p-0 border-0 min-w-full min-h-full resize-none outline-none rounded-none text-xs font-mono bg-gray-800",
                placeholder: props.placeholder,
                disabled: props.disabled,
                value: schema
            })
        ]
    });
};
/* harmony default export */ const modeldisplay = (ModelDisplay);

;// CONCATENATED MODULE: ./components/progresssteps.tsx



const ProgressSteps = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            "data-aos": "fade-up",
            "data-aos-delay": "200",
            className: "flex flex-col",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    className: "steps align-center mb-2",
                    children: props.steps.map((element, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: (0,clsx/* default */.Z)({
                                "step": true
                            }, {
                                "step-primary": props.progress >= index + 1
                            }),
                            children: element
                        }, index))
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "relative flex py-2 items-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex-grow border-t border-gray-600"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const progresssteps = (ProgressSteps);

;// CONCATENATED MODULE: ./components/autocomplete.tsx



const Autocomplete = (props)=>{
    const [suggestions, setSuggestions] = compiled_react_default().useState([]);
    const [selectedOptionKey, setSelectedOptionKey] = compiled_react_default().useState("");
    const [selectedOptionIndex, setSelectedOptionIndex] = compiled_react_default().useState(-1);
    const [optionKeys, setOptionKeys] = compiled_react_default().useState([]);
    // i/p data
    const [value, setValue] = compiled_react_default().useState("");
    const resetAllValues = ()=>{
        setSuggestions([]);
        setSelectedOptionKey("");
        setSelectedOptionIndex(-1);
    };
    const updateSuggestions = (event)=>{
        resetAllValues();
        // Update suggestions based on last token
        var curToken = event.target.value.split(" ").pop() || "";
        console.log("Update suggestions triggered. Finding suggestions with prefix:", curToken);
        // Filter suggestions based on curToken prefix
        let filteredSuggestions = props.initialSuggestion.filter((curSuggestion)=>curSuggestion.displayName.startsWith(curToken));
        setSuggestions(filteredSuggestions);
        console.log("Found suggestions:", filteredSuggestions.map((i)=>{
            return i.displayName;
        }));
        // Update option keys
        let newOptionKeys = filteredSuggestions.map((i)=>i.id);
        setOptionKeys(newOptionKeys);
        console.log("Option keys:", newOptionKeys);
        // Make the first suggestion as selected
        setSelectedOptionIndex(0);
        setSelectedOptionKey(newOptionKeys[0]);
    };
    const valueChanged = async (event)=>{
        updateSuggestions(event);
        // Set current value
        setValue(event.target.value);
        props.onChange(event.target.value);
    };
    const onKeyPressDown = async (e)=>{
        if (e.key == "ArrowDown") {
            onKeyUpDownArrow(e, 1);
        } else if (e.key == "ArrowUp") {
            onKeyUpDownArrow(e, -1);
        } else if (e.key == "Enter") {
            onKeyEnter();
        } else if (e.key == "Escape") {
            resetAllValues();
        }
    };
    const selectSuggestionIndex = async (index)=>{
        console.log("newIndex:", index);
        console.log("optionKeys[newIndex]:", optionKeys[index]);
        setSelectedOptionIndex(index);
        setSelectedOptionKey(optionKeys[index]);
    };
    const onKeyUpDownArrow = async (event, step)=>{
        console.log("Pressed up-down key", step);
        if (suggestions.length == 0) {
            // Pressed for  the first time
            updateSuggestions(event);
            return;
        }
        let newIndex = Math.abs(selectedOptionIndex + step) % optionKeys.length;
        selectSuggestionIndex(newIndex);
    };
    const onKeyEnter = async ()=>{
        console.log("Filtered suggestions:", suggestions);
        console.log("selectedOptionKey:", selectedOptionKey);
        let selectedValue = suggestions.filter((curSuggestion)=>curSuggestion.id.startsWith(selectedOptionKey))[0];
        console.log("selectedValue:", selectedValue);
        selectSuggestion(selectedValue);
    };
    const selectSuggestion = async (selectedSuggestion)=>{
        console.log("Suggestion selected:", selectedSuggestion.displayName);
        // Update the last value in the value list
        var tokens = value.split(" ");
        console.log("Before applying suggestion:", value);
        console.log(tokens);
        tokens.pop();
        tokens.push(selectedSuggestion.displayName);
        console.log(tokens);
        console.log("After applying suggestion:", tokens.join(" "));
        setValue(tokens.join(" "));
        props.onChange(tokens.join(" "));
        resetAllValues();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col w-full relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                value: value,
                onChange: valueChanged,
                onKeyDown: onKeyPressDown,
                type: "text",
                placeholder: props.placeholder,
                className: "input input-xs input-bordered rounded-none font-mono w-full p-0 m-0 disabled:bg-gray-800",
                disabled: props.disabled
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute top-6 left-0 w-full join-vertical overlay",
                children: suggestions.map((e)=>/*#__PURE__*/ jsx_runtime_.jsx("p", {
                        onClick: ()=>selectSuggestion(e),
                        className: (0,clsx/* default */.Z)({
                            "join-item text-sm font-mono py-1 px-2 cursor-pointer bg-gray-700 hover:bg-gray-800": true
                        }, {
                            "bg-gray-800": e.id == selectedOptionKey
                        }),
                        children: e.displayName
                    }, e.id))
            })
        ]
    });
};
/* harmony default export */ const autocomplete = (Autocomplete);

;// CONCATENATED MODULE: ./components/ruleselector.tsx





const RuleDataSetter = (props)=>{
    const [rule, setRule] = compiled_react_default().useState({
        order: 0,
        id: "",
        condition_data: "",
        action_data: ""
    });
    const supportedOperators = [
        {
            "id": (0,v4/* default */.Z)(),
            name: "EQUALS_TO",
            displayName: "=="
        },
        {
            "id": (0,v4/* default */.Z)(),
            name: "GREATER_THAN_OR_EQUAL_TO",
            displayName: ">="
        },
        {
            "id": (0,v4/* default */.Z)(),
            name: "LESSER_THAN_OR_EQUAL_TO",
            displayName: "<="
        },
        {
            "id": (0,v4/* default */.Z)(),
            name: "STARTS_WITH",
            displayName: "=~"
        }
    ];
    const supportedLogicalOperators = [
        {
            "id": (0,v4/* default */.Z)(),
            name: "AND",
            displayName: "&&"
        },
        {
            "id": (0,v4/* default */.Z)(),
            name: "OR",
            displayName: "||"
        }
    ];
    const conditionChanged = async (event)=>{
        rule.condition_data = "IF: { " + event + " }";
        setRule(rule);
        props.ruleUpdatedCB(props.id, rule);
    };
    const actionChanged = async (event)=>{
        rule.action_data = event;
        setRule(rule);
        props.ruleUpdatedCB(props.id, rule);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col w-full",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mb-2",
                children: [
                    "IF ",
                    /*#__PURE__*/ jsx_runtime_.jsx(autocomplete, {
                        onChange: conditionChanged,
                        initialSuggestion: props.initialSuggestion.concat(supportedOperators, supportedLogicalOperators),
                        placeholder: "Press up/down arrow key to select fields",
                        disabled: props.disabled
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "pl-10 mb-6 h-20",
                children: [
                    "THEN",
                    /*#__PURE__*/ jsx_runtime_.jsx(modeldisplay, {
                        onChange: actionChanged,
                        disabled: props.disabled,
                        placeholder: "Please enter JSON response"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const ruleselector = (RuleDataSetter);

// EXTERNAL MODULE: ./lib/interceptors/axios.ts
var axios = __webpack_require__(454);
;// CONCATENATED MODULE: ./lib/interceptors/hooks/useRefreshToken.ts
/* __next_internal_client_entry_do_not_use__ useRefreshToken auto */ 

const useRefreshToken = ()=>{
    const { data: session  } = (0,react.useSession)();
    const refreshToken = async ()=>{
        axios/* default.post */.Z.post("/v1/refresh", {
            refreshToken: session?.user.refreshToken
        }).then((resp)=>{
            if (session) session.user.accessToken = resp.data.success?.data?.accessToken;
        }).catch((error)=>{
            console.log(error);
            // Clear the token
            (0,react.signIn)();
        });
    };
    return refreshToken;
};

;// CONCATENATED MODULE: ./lib/interceptors/hooks/useAxiosAuth.ts
/* __next_internal_client_entry_do_not_use__ default auto */ 



function useAxiosAuth() {
    const { data: session  } = (0,react.useSession)();
    const refreshToken = useRefreshToken();
    (0,react_.useEffect)(()=>{
        const requestIntercept = axios/* axiosAuth.interceptors.request.use */.v.interceptors.request.use((config)=>{
            if (!config.headers["Token"]) {
                config.headers["Token"] = `${session?.user?.accessToken}`;
            }
            return config;
        }, (error)=>Promise.reject(error));
        const responseIntercept = axios/* axiosAuth.interceptors.response.use */.v.interceptors.response.use((response)=>response, async (error)=>{
            const prevRequest = error?.config;
            if (error?.response?.status === 401 && !prevRequest?.sent) {
                prevRequest.sent = true;
                await refreshToken();
                prevRequest.headers["Token"] = `${session?.user.accessToken}`;
                return (0,axios/* axiosAuth */.v)(prevRequest);
            }
            return Promise.reject(error);
        });
        return ()=>{
            axios/* axiosAuth.interceptors.request.eject */.v.interceptors.request.eject(requestIntercept);
            axios/* axiosAuth.interceptors.response.eject */.v.interceptors.response.eject(responseIntercept);
        };
    }, [
        session,
        refreshToken
    ]);
    return axios/* axiosAuth */.v;
}

;// CONCATENATED MODULE: ./app/(static)/getstarted/get-started.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 














const GetStarted = ()=>{
    const [progress, setProgress] = compiled_react_default().useState(1);
    const [errorMsg, setErrorMsg] = compiled_react_default().useState("");
    const [showAPIKey, setShowAPIKey] = compiled_react_default().useState(false);
    // Auth states
    const { data: session  } = (0,react.useSession)();
    const axiosAuth = useAxiosAuth();
    const router = (0,navigation.useRouter)();
    // Stream states
    const [schema, setSchema] = compiled_react_default().useState("");
    const [streamName, setStreamName] = compiled_react_default().useState("");
    const [streamID, setStreamID] = compiled_react_default().useState("");
    const [streamData, setStreamData] = compiled_react_default().useState("");
    const [schemaKeys, setStreamSchemaKeys] = compiled_react_default().useState([]);
    // Rule states
    const [ruleName, setRuleName] = compiled_react_default().useState("");
    // string vs Rule(aka condition-action pair)
    const [ruleMap, setRuleMap] = compiled_react_default().useState(new Map());
    // Total rules
    const [totalRules, setTotalRules] = compiled_react_default().useState(1);
    // Test rule
    const [testData, setTestData] = compiled_react_default().useState("");
    const [testResultData, setTestResultData] = compiled_react_default().useState([]);
    const onStreamNameChange = async (streamName)=>{
        setStreamName(streamName);
    };
    const checkStreamName = async ()=>{
        // Check for empty name
        if (streamName.length == 0) {
            setErrorMsg("Stream name cannot be empty");
            return false;
        }
        // Check for duplicate name
        return await axiosAuth.get("/v1/stream?name=" + streamName).then((resp)=>{
            let data = resp.data;
            if (data.success?.data != null) {
                setErrorMsg("Stream with this name already exists");
                return false;
            } else {
                return true;
                setErrorMsg("");
            }
        }).catch((err)=>{
            setErrorMsg("Session expired. Please login");
            return false;
        });
    };
    const showHidePassword = ()=>{
        setShowAPIKey(!showAPIKey);
    };
    const validateStreamSchema = ()=>{
        try {
            JSON.parse(schema);
            setErrorMsg("");
            return true;
        } catch (e) {
            setErrorMsg("Please enter valid JSON");
            return false;
        }
    };
    const createStream = async ()=>{
        const createStreamReq = {
            name: streamName,
            schema: schema
        };
        var resp;
        return await axiosAuth.put("/v1/stream", createStreamReq).then((resp)=>{
            let data = resp.data;
            if (data.success?.data != null) {
                var schemaLoc = [];
                console.log(data);
                data.success.data[0].schema_keys.forEach((element)=>{
                    schemaLoc.push({
                        id: (0,v4/* default */.Z)(),
                        name: element,
                        displayName: element
                    });
                });
                console.log(schemaLoc);
                console.log(JSON.stringify(JSON.parse(data.success.data[0].schema), null, "	"));
                setStreamData(JSON.stringify(JSON.parse(data.success.data[0].schema), null, "	"));
                setStreamSchemaKeys(schemaLoc);
                setStreamID(data.success.data[0].id);
                setErrorMsg("");
                return true;
            }
        }).catch((error)=>{
            resp = error.response?.data;
            setErrorMsg(resp.error?.msg || "");
            return false;
        });
    };
    const clearRules = async ()=>{
        setRuleMap(new Map());
        setTotalRules(1);
    };
    const addNewRule = async ()=>{
        let ruleID = (0,v4/* default */.Z)();
        setRuleMap(new Map(ruleMap.set(ruleID, {
            id: ruleID,
            order: totalRules,
            condition_data: "",
            action_data: ""
        })));
        setTotalRules(totalRules + 1);
    };
    const removeRule = async (ruleId)=>{
        ruleMap.delete(ruleId);
        setRuleMap(new Map(ruleMap));
    };
    const updateRule = async (ruleId, rule)=>{
        setRuleMap(new Map(ruleMap.set(ruleId, rule)));
        console.log(ruleMap);
    };
    const onRuleNameChange = async (ruleName)=>{
        setRuleName(ruleName);
    };
    const checkRuleName = async ()=>{
        if (ruleName.length == 0) {
            setErrorMsg("Rule name cannot be empty");
            return false;
        }
        // Check for duplicate name
        return await axiosAuth.get("/v1/rule?name=" + ruleName).then((resp)=>{
            let data = resp.data;
            if (data.success?.data != null) {
                setErrorMsg("Rule with this name already exists");
                return false;
            } else {
                setErrorMsg("");
                return true;
            }
        }).catch((err)=>{
            setErrorMsg("Session expired. Please login");
        });
    };
    const createRule = async ()=>{
        const createRuleRequest = {
            name: ruleName,
            data: Array.from(ruleMap.values())
        };
        var resp;
        return await axiosAuth.put("/v1/rule", createRuleRequest).then((resp)=>{
            let data = resp.data;
            if (data.success?.data != null) {
                let ruleID = data.success.data.id;
                console.log("Rule creation success:", ruleID);
                const updateStreamRequest = {
                    stream_id: streamID,
                    rule_id: ruleID,
                    status: 1
                };
                axiosAuth.post("/v1/stream", updateStreamRequest).then((resp)=>{
                    let data = resp.data;
                    console.log("Update stream request success:" + data);
                }).catch((error)=>{
                    let resp = error.response?.data;
                    console.log("Update stream request error:" + resp);
                    setErrorMsg("Error while creating rule");
                    return false;
                });
            }
            console.log(data);
            return true;
        }).catch((error)=>{
            resp = error.response?.data;
            setErrorMsg(resp.error?.msg || "");
            return false;
        });
    };
    const nextStep = async ()=>{
        let curStep = progress;
        if (curStep == 1) {
            // TODO: Add validation
            setProgress(progress + 1);
        } else if (curStep == 2) {
            // Check JSON validity
            if (!validateStreamSchema()) {
                return;
            }
            console.log("Stream schema valid");
            // Check stream name validity
            let streamNameOK = await checkStreamName();
            console.log("Validation of stream name:", streamNameOK);
            if (!streamNameOK) {
                return;
            }
            // Create stream
            let createStreamOK = await createStream();
            console.log("Stream created successfully:", createStreamOK);
            if (createStreamOK) {
                addNewRule();
                setProgress(progress + 1);
            }
        } else if (curStep == 3) {
            let ruleNameOk = await checkRuleName();
            if (!ruleNameOk) {
                return;
            }
            let createRuleOK = await createRule();
            if (createRuleOK) {
                setProgress(progress + 1);
            }
        } else if (curStep == 4) {
            createStream();
        }
    };
    const prevStep = async ()=>{
        setErrorMsg("");
        setProgress(progress - 1);
    };
    const evaluateTestData = async ()=>{
        const evaluateRuleRequest = {
            id: "1",
            data: JSON.parse(testData)
        };
        var resp;
        return await axiosAuth.post("/v1/rule/evaluate/" + streamID, evaluateRuleRequest).then((resp)=>{
            let data = resp.data;
            if (data.success?.data.success != null) {
                let results = data.success.data.success.map((e)=>{
                    return e.result;
                });
                console.log("Final results", results);
                setTestResultData(results);
                setErrorMsg("");
                return true;
            } else {
                setTestResultData([
                    "No rules evaluated to true"
                ]);
            }
        }).catch((error)=>{
            resp = error.response?.data;
            setErrorMsg(resp.error?.msg || "");
            return false;
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "max-w-6xl mx-auto px-4 py-8 sm:px-6 md:py-40 border-gray-800",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    "data-aos": "fade-up",
                    "data-aos-delay": "200",
                    className: "flex flex-col mx-2 p-2",
                    children: [
                        progress > 0 && /*#__PURE__*/ jsx_runtime_.jsx(progresssteps, {
                            progress: progress,
                            steps: [
                                "Generate key",
                                "Register schema",
                                "Create rule",
                                "Test rule"
                            ]
                        }),
                        !!errorMsg && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "bg-red-100 text-red-600 text-center font-semibold p-2",
                            children: errorMsg
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "join join-vertical w-full",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "collapse collapse-arrow join-item border border-base-300",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "radio",
                                            readOnly: true,
                                            name: "accordian-steps",
                                            checked: progress == 1
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "collapse-title p-0 text-xl font-medium",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                                className: "h4 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "font-architects-daughter text-xxl text-purple-600 mb-2 inline-block",
                                                        children: "Step 1 - "
                                                    }),
                                                    " Generate API token"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "collapse-content",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-row w-full",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(labelledinput, {
                                                        type: showAPIKey ? "text" : "password",
                                                        onChange: onStreamNameChange,
                                                        value: session?.user.accessToken,
                                                        label: "API Token",
                                                        top_label: "",
                                                        disabled: progress > 1
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome.FontAwesomeIcon, {
                                                        onClick: ()=>showHidePassword(),
                                                        icon: free_solid_svg_icons/* faEye */.Mdf,
                                                        className: "ml-5 mt-1 cursor-pointer hover:text-indigo-500"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "collapse collapse-arrow join-item border border-base-300",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "radio",
                                            readOnly: true,
                                            name: "accordian-steps",
                                            checked: progress == 2
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "collapse-title p-0 text-xl font-medium",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                                className: "h4 mb-1",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "font-architects-daughter text-xxl text-purple-600 mb-2 inline-block",
                                                        children: "Step 2 - "
                                                    }),
                                                    " Register schema"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "collapse-content",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                "data-aos": "fade-up",
                                                "data-aos-delay": "200",
                                                className: "form-control mt-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(labelledinput, {
                                                        type: "text",
                                                        onChange: onStreamNameChange,
                                                        placeholder: "Ex:add-cash-events",
                                                        label: "Stream name",
                                                        top_label: "Choose a unique stream name",
                                                        disabled: progress > 2
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        className: "label",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "label-text",
                                                            children: "Input sample event for registering schema"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(modeldisplay, {
                                                        placeholder: '{ "amount": 100, "type": "CC" }',
                                                        disabled: progress > 2,
                                                        onChange: setSchema
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "collapse collapse-arrow join-item border border-base-300",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "radio",
                                            readOnly: true,
                                            name: "accordian-steps",
                                            checked: progress == 3
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "collapse-title p-0 text-xl font-medium",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                                className: "h4 mb-1",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "font-architects-daughter text-xxl text-purple-600 mb-2 inline-block",
                                                        children: "Step 3 - "
                                                    }),
                                                    " Create rule"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "collapse-content",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                "data-aos": "fade-up",
                                                "data-aos-delay": "200",
                                                className: "form-control mt-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(labelledinput, {
                                                        type: "text",
                                                        onChange: onRuleNameChange,
                                                        label: "Rule name",
                                                        top_label: "Choose a unique rule name",
                                                        disabled: progress > 3
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(label, {
                                                        label: "Configure conditions",
                                                        disabled: progress > 4
                                                    }),
                                                    [
                                                        ...ruleMap.entries()
                                                    ].map(([ruleID, rule])=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex flex-row-reverse justify-around border-dashed border rounded-sm border-gray-500 px-6 py-2",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome.FontAwesomeIcon, {
                                                                    onClick: progress == 3 && rule.order > 1 ? ()=>removeRule(ruleID) : undefined,
                                                                    icon: free_solid_svg_icons/* faCircleMinus */.W7v,
                                                                    className: (0,clsx/* default */.Z)({
                                                                        "": true
                                                                    }, {
                                                                        "text-custom-red cursor-pointer hover:text-indigo-700": progress == 3 && rule.order > 1
                                                                    }, {
                                                                        "text-gray-600 cursor-not-allowed": progress > 3 || rule.order == 1
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: "flex grow",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ruleselector, {
                                                                        initialSuggestion: schemaKeys,
                                                                        id: ruleID,
                                                                        ruleUpdatedCB: updateRule,
                                                                        disabled: progress >= 4
                                                                    })
                                                                })
                                                            ]
                                                        }, ruleID)),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(components_button, {
                                                        onClick: ()=>addNewRule(),
                                                        licon: free_solid_svg_icons/* faCirclePlus */.EQ8,
                                                        text: "Add rule"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "collapse collapse-arrow join-item border border-base-300",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "radio",
                                            readOnly: true,
                                            name: "accordian-steps",
                                            checked: progress == 4
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "collapse-title p-0 text-xl font-medium",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                                className: "h4 mb-1",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "font-architects-daughter text-xxl text-purple-600 mb-2 inline-block",
                                                        children: "Step 4 - "
                                                    }),
                                                    " Test rule"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "collapse-content",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                "data-aos": "fade-up",
                                                "data-aos-delay": "200",
                                                className: "form-control mt-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        className: "label",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "label-text",
                                                            children: "Input test event"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex flex-row justify-around",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "basis-4/12",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(modeldisplay, {
                                                                    onChange: setTestData,
                                                                    disabled: false,
                                                                    placeholder: "Enter sample event"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(components_button, {
                                                                onClick: evaluateTestData,
                                                                className: "2/12",
                                                                ricon: free_solid_svg_icons/* faArrowRight */.eFW,
                                                                text: "Evaluate"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "basis-4/12",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                                    value: testResultData,
                                                                    className: "textarea m-0 p-0 border-1 min-w-full min-h-full resize-none rounded-none text-xs font-mono bg-gray-800"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    "data-aos": "fade-down",
                    "data-aos-delay": "200",
                    className: (0,clsx/* default */.Z)({
                        "flex flex-row mt-12": true
                    }, {
                        "justify-end": progress == 0
                    }, {
                        "justify-between": progress >= 1
                    }),
                    children: [
                        progress >= 1 && /*#__PURE__*/ jsx_runtime_.jsx(components_button, {
                            onClick: prevStep,
                            licon: free_solid_svg_icons/* faArrowLeft */.acZ,
                            text: "Back"
                        }),
                        progress >= 1 && progress <= 3 && /*#__PURE__*/ jsx_runtime_.jsx(components_button, {
                            onClick: nextStep,
                            ricon: free_solid_svg_icons/* faArrowRight */.eFW,
                            text: "Next"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const get_started = (GetStarted);

;// CONCATENATED MODULE: ./app/(static)/getstarted/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





function Documentation() {
    const { data: session  } = (0,react.useSession)();
    if (session) {
        return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(get_started, {})
        });
    } else {
        return /*#__PURE__*/ jsx_runtime_.jsx("section", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "max-w-12xl mx-auto px-4 sm:px-6 relative",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "relative pt-32 pb-10 md:pt-40 md:pb-16",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex col-span-6 justify-center",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            onClick: ()=>(0,react.signIn)(),
                            type: "submit",
                            className: "flex items-center justify-center border border-transparent bg-indigo-600 px-8 py-3 text-base font-medium text-indigo-100 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2",
                            children: [
                                "  Generate your token ",
                                /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome.FontAwesomeIcon, {
                                    icon: free_solid_svg_icons/* faArrowRight */.eFW,
                                    className: "pl-4 text-indigo-100"
                                })
                            ]
                        })
                    })
                })
            })
        });
    }
}


/***/ }),

/***/ 4442:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/pshanbhag/FraudGuard/APIWebsite/app/(static)/getstarted/layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 3027:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/pshanbhag/FraudGuard/APIWebsite/app/(static)/getstarted/page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [683,853,902,979,248,370,668,122,990,90], () => (__webpack_exec__(4903)));
module.exports = __webpack_exports__;

})();