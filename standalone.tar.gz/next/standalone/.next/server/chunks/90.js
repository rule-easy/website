"use strict";
exports.id = 90;
exports.ids = [90];
exports.modules = {

/***/ 454:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "v": () => (/* binding */ axiosAuth)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(248);

// https://github.com/vahid-nejad/Refresh-Token-Next-Auth
// GetEnvConfig().then((config) => {
//     const env: Config = config
//     const BASE_URL = env.backendHost
// })
// const BASE_URL = "http://localhost:8080";
const BASE_URL = "http://api.patternact.com";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].create */ .Z.create({
    baseURL: BASE_URL,
    headers: {
        "Content-Type": "application/json"
    }
}));
const axiosAuth = axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].create */ .Z.create({
    baseURL: BASE_URL,
    headers: {
        "Content-Type": "application/json"
    }
});


/***/ })

};
;